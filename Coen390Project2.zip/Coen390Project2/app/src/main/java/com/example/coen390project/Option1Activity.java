
package com.example.coen390project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Option1Activity extends AppCompatActivity {

    private LinearLayout cardAbs, cardArms, cardLegs, cardChest, cardBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option1);

        Toolbar toolbar = findViewById(R.id.optionToolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Workouts");
        }

        cardAbs = findViewById(R.id.cardAbs);
        cardArms = findViewById(R.id.cardArms);
        cardLegs = findViewById(R.id.cardLegs);
        cardChest = findViewById(R.id.cardChest);
        cardBack = findViewById(R.id.cardBack);

        cardAbs.setOnClickListener(v -> openExerciseList("Abdomen"));
        cardArms.setOnClickListener(v -> openExerciseList("Arms"));
        cardLegs.setOnClickListener(v -> openExerciseList("Legs"));
        cardChest.setOnClickListener(v -> openExerciseList("Chest"));
        cardBack.setOnClickListener(v -> openExerciseList("Back"));
    }

    private void openExerciseList(String category) {
        Intent intent = new Intent(Option1Activity.this,
                ExerciseListActivity.class);

        intent.putExtra("CATEGORY", category);
        startActivity(intent);
    }
}
