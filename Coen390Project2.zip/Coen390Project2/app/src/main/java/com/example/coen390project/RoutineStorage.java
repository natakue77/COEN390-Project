
package com.example.coen390project;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;

public class RoutineStorage {

    private static final String PREF_NAME = "WorkoutPreferences";
    private static final String ROUTINE_KEY = "myRoutine";

    public static ArrayList<String> getExercises(Context context) {

        SharedPreferences preferences =
                context.getSharedPreferences(
                        PREF_NAME, Context.MODE_PRIVATE);

        String savedData = preferences.getString(
                ROUTINE_KEY, "[]");

        ArrayList<String> exercises = new ArrayList<>();

        try {
            JSONArray array = new JSONArray(savedData);

            for (int i = 0; i < array.length(); i++) {
                exercises.add(array.getString(i));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return exercises;
    }

    public static boolean addExercise(
            Context context, String exercise) {

        ArrayList<String> exercises = getExercises(context);

        if (exercises.contains(exercise)) {
            return false;
        }

        exercises.add(exercise);

        saveExercises(context, exercises);

        return true;
    }

    public static void removeExercise(
            Context context, String exercise) {

        ArrayList<String> exercises = getExercises(context);

        exercises.remove(exercise);

        saveExercises(context, exercises);
    }

    private static void saveExercises(
            Context context, ArrayList<String> exercises) {

        JSONArray array = new JSONArray();

        for (String exercise : exercises) {
            array.put(exercise);
        }

        SharedPreferences preferences =
                context.getSharedPreferences(
                        PREF_NAME, Context.MODE_PRIVATE);

        preferences.edit()
                .putString(ROUTINE_KEY, array.toString())
                .apply();
    }
}
