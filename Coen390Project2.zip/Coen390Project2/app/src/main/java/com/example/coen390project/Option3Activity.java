
package com.example.coen390project;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;

public class Option3Activity extends AppCompatActivity {

    private LinearLayout routineList;
    private TextView routineCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option3);

        Toolbar toolbar = findViewById(R.id.optionToolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        routineList = findViewById(R.id.routineList);
        routineCount = findViewById(R.id.routineCount);

        displayRoutine();
    }

    private void displayRoutine() {

        routineList.removeAllViews();

        ArrayList<String> exercises =
                RoutineStorage.getExercises(this);

        routineCount.setText(
                "Exercises in your routine: " + exercises.size()
        );

        if (exercises.isEmpty()) {

            TextView emptyMessage = new TextView(this);

            emptyMessage.setText(
                    "Your routine is empty.\n\n" +
                            "Go to Workouts to add exercises!"
            );

            emptyMessage.setTextSize(18);

            routineList.addView(emptyMessage);

            return;
        }

        for (String exercise : exercises) {

            Button exerciseButton = new Button(this);

            exerciseButton.setText(
                    exercise + " - Remove"
            );

            exerciseButton.setOnClickListener(v -> {

                RoutineStorage.removeExercise(
                        Option3Activity.this,
                        exercise
                );

                Toast.makeText(
                        this,
                        exercise + " removed from your routine",
                        Toast.LENGTH_SHORT
                ).show();

                displayRoutine();
            });

            routineList.addView(exerciseButton);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (routineList != null) {
            displayRoutine();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
