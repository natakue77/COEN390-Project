
package com.example.coen390project;

import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;

public class ExerciseListActivity extends AppCompatActivity {

    private LinearLayout exerciseContainer;
    private TextView tvCategoryTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_list);

        Toolbar toolbar = findViewById(R.id.exerciseToolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        exerciseContainer = findViewById(R.id.exerciseContainer);
        tvCategoryTitle = findViewById(R.id.tvCategoryTitle);

        String category = getIntent().getStringExtra("CATEGORY");

        if (category == null) {
            category = "Abdomen";
        }

        tvCategoryTitle.setText(category + " Exercises");

        displayExercises(category);
    }

    private void displayExercises(String category) {

        ArrayList<String> exercises = new ArrayList<>();

        switch (category) {

            case "Abdomen":
                exercises.add("Crunches");
                exercises.add("Plank");
                exercises.add("Leg Raises");
                exercises.add("Russian Twists");
                exercises.add("Mountain Climbers");
                break;

            case "Arms":
                exercises.add("Bicep Curls");
                exercises.add("Tricep Extensions");
                exercises.add("Hammer Curls");
                exercises.add("Shoulder Press");
                exercises.add("Lateral Raises");
                break;

            case "Legs":
                exercises.add("Squats");
                exercises.add("Lunges");
                exercises.add("Leg Press");
                exercises.add("Calf Raises");
                exercises.add("Glute Bridges");
                break;

            case "Chest":
                exercises.add("Push-Ups");
                exercises.add("Bench Press");
                exercises.add("Incline Dumbbell Press");
                exercises.add("Chest Flyes");
                exercises.add("Cable Crossovers");
                break;

            case "Back":
                exercises.add("Pull-Ups");
                exercises.add("Lat Pulldowns");
                exercises.add("Bent-Over Rows");
                exercises.add("Seated Cable Rows");
                exercises.add("Deadlifts");
                break;
        }

        for (String exercise : exercises) {
            addExerciseCard(exercise);
        }
    }

    private void addExerciseCard(String exerciseName) {

        TextView exerciseCard = new TextView(this);

        exerciseCard.setText(exerciseName);
        exerciseCard.setTextColor(0xFFFFFFFF);
        exerciseCard.setTextSize(16);
        exerciseCard.setGravity(Gravity.CENTER_VERTICAL);
        exerciseCard.setPadding(20, 20, 20, 20);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        75
                );

        params.setMargins(0, 0, 0, 12);

        exerciseCard.setLayoutParams(params);
        exerciseCard.setBackgroundResource(R.drawable.equipment_card);

        exerciseContainer.addView(exerciseCard);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
