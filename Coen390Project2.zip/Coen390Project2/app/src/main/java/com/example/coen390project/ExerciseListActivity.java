
package com.example.coen390project;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;

public class ExerciseListActivity extends AppCompatActivity {

    private LinearLayout exerciseContainer;
    private TextView tvCategoryTitle;

    private boolean routineSelectionMode;

    private final ArrayList<CheckBox> exerciseCheckBoxes =
            new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_list);

        Toolbar toolbar = findViewById(R.id.exerciseToolbar);

        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Exercises");
        }

        toolbar.setNavigationOnClickListener(v -> finish());

        exerciseContainer = findViewById(R.id.exerciseContainer);
        tvCategoryTitle = findViewById(R.id.tvCategoryTitle);

        routineSelectionMode = getIntent().getBooleanExtra(
                "ROUTINE_SELECTION_MODE", false);

        String category = getIntent().getStringExtra("CATEGORY");

        if (category == null) {
            category = "Abdomen";
        }

        tvCategoryTitle.setText(category + " Exercises");

        displayExercises(category);

        if (routineSelectionMode) {
            addRoutineButton();
        }
    }

    private void displayExercises(String category) {

        ArrayList<String> exercises = new ArrayList<>();

        switch (category) {

            case "Abdomen":
                exercises.add("Crunches");
                exercises.add("Plank");
                exercises.add("Leg Raises");
                exercises.add("Russian Twists");
                exercises.add("Mountain Climbers");
                break;

            case "Arms":
                exercises.add("Bicep Curls");
                exercises.add("Tricep Extensions");
                exercises.add("Hammer Curls");
                exercises.add("Shoulder Press");
                exercises.add("Lateral Raises");
                break;

            case "Legs":
                exercises.add("Squats");
                exercises.add("Lunges");
                exercises.add("Leg Press");
                exercises.add("Calf Raises");
                exercises.add("Glute Bridges");
                break;

            case "Chest":
                exercises.add("Push-Ups");
                exercises.add("Bench Press");
                exercises.add("Incline Dumbbell Press");
                exercises.add("Chest Flyes");
                exercises.add("Cable Crossovers");
                break;

            case "Back":
                exercises.add("Pull-Ups");
                exercises.add("Lat Pulldowns");
                exercises.add("Bent-Over Rows");
                exercises.add("Seated Cable Rows");
                exercises.add("Deadlifts");
                break;
        }

        for (String exercise : exercises) {
            addExerciseCard(exercise);
        }
    }

    private void addExerciseCard(String exerciseName) {

        if (routineSelectionMode) {

            CheckBox checkBox = new CheckBox(this);

            checkBox.setText(exerciseName);
            checkBox.setTextColor(0xFFFFFFFF);
            checkBox.setTextSize(16);
            checkBox.setPadding(20, 15, 20, 15);

            checkBox.setButtonTintList(
                    android.content.res.ColorStateList.valueOf(
                            0xFFFFFFFF
                    )
            );

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            75
                    );

            params.setMargins(0, 0, 0, 12);

            checkBox.setLayoutParams(params);
            checkBox.setBackgroundResource(R.drawable.equipment_card);

            exerciseContainer.addView(checkBox);
            exerciseCheckBoxes.add(checkBox);

        } else {

            TextView exerciseCard = new TextView(this);

            exerciseCard.setText(exerciseName);
            exerciseCard.setTextColor(0xFFFFFFFF);
            exerciseCard.setTextSize(16);
            exerciseCard.setGravity(Gravity.CENTER_VERTICAL);
            exerciseCard.setPadding(20, 20, 20, 20);

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            75
                    );

            params.setMargins(0, 0, 0, 12);

            exerciseCard.setLayoutParams(params);
            exerciseCard.setBackgroundResource(R.drawable.equipment_card);

            exerciseContainer.addView(exerciseCard);
        }
    }

    private void addRoutineButton() {

        Button addButton = new Button(this);

        addButton.setText("Add Workout");
        addButton.setAllCaps(false);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        params.setMargins(0, 12, 0, 24);

        addButton.setLayoutParams(params);

        exerciseContainer.addView(addButton);

        addButton.setOnClickListener(v -> {

            ArrayList<String> selectedExercises = new ArrayList<>();

            for (CheckBox checkBox : exerciseCheckBoxes) {

                if (checkBox.isChecked()) {
                    selectedExercises.add(
                            checkBox.getText().toString()
                    );
                }
            }

            if (selectedExercises.isEmpty()) {

                Toast.makeText(
                        this,
                        "Please select at least one exercise.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            Intent result = new Intent();

            result.putStringArrayListExtra(
                    "SELECTED_EXERCISES",
                    selectedExercises
            );

            setResult(RESULT_OK, result);

            // Returns to Option1Activity, not My Routine
            finish();
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
